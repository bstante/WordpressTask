<h2><?php echo $settings->text; ?></h2>
<?php if ( ! empty( $settings->add_subheadline ) ): ?>
<h4><?php echo $settings->sub_text; ?></h4>
<?php endif; ?>
