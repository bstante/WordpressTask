<polygon class="fl-shape" points="0,0 800,0 800,50 400,0 0,50"></polygon>
