<!DOCTYPE html>
<html lang="en">
  <head>
     <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"> </script>

<link rel="stylesheet" href="/wordpress/wordpress/wp-content/themes/org/style.css">  
<!-- <link rel="stylesheet" href="jquery.orgchart.min.css"> -->

<script>
let url = "http://58.69.15.211:8080/api/user/orgChart/?token=c1f22a6d7f7615cfd890c4507c1f231f";
    
    var xmlhttp = new XMLHttpRequest();
xmlhttp.onreadystatechange = function() {
  if (this.readyState == 4 && this.status == 200) {
    

    var myObj = JSON.parse(this.responseText);
  
   var HR =" ";
    CT = " ";
    DO = " ";
    var CEO = (myObj.list[0].first_name + " " + myObj.list[0].last_name + " " + myObj.list[0].position);

console.log(myObj.list[0].first_name,myObj.list[0].last_name,myObj.list[0].position);
document.getElementById("ceo").innerHTML = CEO;




}
};
 

xmlhttp.open("POST", url, true);
xmlhttp.send();
</script>



</head>
 <body>

