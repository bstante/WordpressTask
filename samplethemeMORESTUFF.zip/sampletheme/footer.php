       

        <footer>
          <div class="pull-right">
            Gentelella - Bootstrap Admin Template by <a href="http://localhost/wordpress/">Colorlib</a>
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="/wordpress/wp-content/themes/sampletheme/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="/wordpress/wp-content/themes/sampletheme/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="/wordpress/wp-content/themes/sampletheme/vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="/wordpress/wp-content/themes/sampletheme/vendors/nprogress/nprogress.js"></script>
    <!-- Chart.js -->
    <script src="/wordpress/wp-content/themes/sampletheme/vendors/Chart.js/dist/Chart.min.js"></script>
    <!-- gauge.js -->
    <script src="/wordpress/wp-content/themes/sampletheme/vendors/gauge.js/dist/gauge.min.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="/wordpress/wp-content/themes/sampletheme/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="/wordpress/wp-content/themes/sampletheme/vendors/iCheck/icheck.min.js"></script>
    <!-- Skycons -->
    <script src="/wordpress/wp-content/themes/sampletheme/vendors/skycons/skycons.js"></script>
    <!-- Flot -->
    <script src="/wordpress/wp-content/themes/sampletheme/vendors/Flot/jquery.flot.js"></script>
    <script src="/wordpress/wp-content/themes/sampletheme/vendors/Flot/jquery.flot.pie.js"></script>
    <script src="/wordpress/wp-content/themes/sampletheme/vendors/Flot/jquery.flot.time.js"></script>
    <script src="/wordpress/wp-content/themes/sampletheme/vendors/Flot/jquery.flot.stack.js"></script>
    <script src="/wordpress/wp-content/themes/sampletheme/vendors/Flot/jquery.flot.resize.js"></script>
    <!-- Flot plugins -->
    <script src="/wordpress/wp-content/themes/sampletheme/vendors/flot.orderbars/js/jquery.flot.orderBars.js"></script>
    <script src="/wordpress/wp-content/themes/sampletheme/vendors/flot-spline/js/jquery.flot.spline.min.js"></script>
    <script src="/wordpress/wp-content/themes/sampletheme/vendors/flot.curvedlines/curvedLines.js"></script>
    <!-- DateJS -->
    <script src="/wordpress/wp-content/themes/sampletheme/vendors/DateJS/build/date.js"></script>
    <!-- JQVMap -->
    <script src="/wordpress/wp-content/themes/sampletheme/vendors/jqvmap/dist/jquery.vmap.js"></script>
    <script src="/wordpress/wp-content/themes/sampletheme/vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
    <script src="/wordpress/wp-content/themes/sampletheme/vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="/wordpress/wp-content/themes/sampletheme/vendors/moment/min/moment.min.js"></script>
    <script src="/wordpress/wp-content/themes/sampletheme/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="/wordpress/wp-content/themes/sampletheme/build/js/custom.min.js"></script>
	
  </body>
</html>
