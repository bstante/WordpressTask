            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>General</h3>
                <ul class="nav side-menu">
                  <li><a><i class="fa fa-home"></i> Home <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a>Dashboard</a></li>
                      <li><a>Dashboard2</a></li>
                      <li><a>Dashboard3</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-edit"></i> Forms <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a>General Form</a></li>
                      <li><a>Advanced Components</a></li>
                      <li><a>Form Validation</a></li>
                      <li><a>Form Wizard</a></li>
                      <li><a>Form Upload</a></li>
                      <li><a>Form Buttons</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-desktop"></i> UI Elements <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a>General Elements</a></li>
                      <li><a>Media Gallery</a></li>
                      <li><a>Typography</a></li>
                      <li><a>Icons</a></li>
                      <li><a>Glyphicons</a></li>
                      <li><a>Widgets</a></li>
                      <li><a>Invoice</a></li>
                      <li><a>Inbox</a></li>
                      <li><a>Calendar</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-table"></i> Tables <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a>Tables</a></li>
                      <li><a>Table Dynamic</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-bar-chart-o"></i> Data Presentation <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a>Chart JS</a></li>
                      <li><a>Chart JS2</a></li>
                      <li><a>Moris JS</a></li>
                      <li><a>ECharts</a></li>
                      <li><a>Other Charts</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-clone"></i>Layouts <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a>Fixed Sidebar</a></li>
                      <li><a>Fixed Footer</a></li>
                    </ul>
                  </li>
                </ul>
              </div>
              <div class="menu_section">
                <h3>Live On</h3>
                <ul class="nav side-menu">
                  <li><a><i class="fa fa-bug"></i> Additional Pages <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a>E-commerce</a></li>
                      <li><a>Projects</a></li>
                      <li><a>Project Detail</a></li>
                      <li><a>Contacts</a></li>
                      <li><a>Profile</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-windows"></i> Extras <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a>403 Error</a></li>
                      <li><a>404 Error</a></li>
                      <li><a>500 Error</a></li>
                      <li><a>Plain Page</a></li>
                      <li><a>Login Page</a></li>
                      <li><a>Pricing Tables</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-sitemap"></i> Multilevel Menu <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                        <li><a>Level One</a>
                        <li><a>Level One<span class="fa fa-chevron-down"></span></a>
                          <ul class="nav child_menu">
                            <li class="sub_menu"><a>Level Two</a>
                            </li>
                            <li><a>Level Two</a>
                            </li>
                            <li><a>Level Two</a>
                            </li>
                          </ul>
                        </li>
                        <li><a>Level One</a>
                        </li>
                    </ul>
                  </li>                  
                  <li><a><i class="fa fa-laptop"></i> Landing Page <span class="label label-success pull-right">Coming Soon</span></a></li>
                </ul>
              </div>

            </div>
            <!-- /sidebar menu -->		