<?php

function my_theme_enqueue_styles() {

	wp_enqueue_style('customstyle', get_template_directory_uri() . '/style.css' );
	wp_enqueue_style('bootstrap', get_stylesheet_directory_uri() . '/vendors/bootstrap/dist/css/bootstrap.min.css' );
	wp_enqueue_style('cust', get_stylesheet_directory_uri() . '/build/css/custom.min.css' );
	wp_enqueue_style('font', get_stylesheet_directory_uri() . '/vendors/font-awesome/css/font-awesome.min.css' );
	wp_enqueue_style('nprog', get_stylesheet_directory_uri() . '/vendors/nprogress/nprogress.css' );
	wp_enqueue_style('icheck', get_stylesheet_directory_uri() . '/vendors/iCheck/skins/flat/green.css' );
	wp_enqueue_style('bootbar', get_stylesheet_directory_uri() . '/vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css' );
	wp_enqueue_style('jqv', get_stylesheet_directory_uri() . '/vendors/jqvmap/dist/jqvmap.min.css" rel="stylesheet' );
	wp_enqueue_style('bootdate', get_stylesheet_directory_uri() . '/vendors/bootstrap-daterangepicker/daterangepicker.css' );
	
	wp_enqueue_script('jqu', get_stylesheet_directory_uri() . '/vendors/jquery/dist/jquery.min.js' );
	wp_enqueue_script('bootst', get_stylesheet_directory_uri() . '/vendors/bootstrap/dist/js/bootstrap.min.js' );
	wp_enqueue_script('fast', get_stylesheet_directory_uri() . '/vendors/fastclick/lib/fastclick.js' );
	wp_enqueue_script('npr', get_stylesheet_directory_uri() . '/vendors/nprogress/nprogress.js' );
	wp_enqueue_script('char', get_stylesheet_directory_uri() . '/vendors/Chart.js/dist/Chart.min.js' );
	wp_enqueue_script('gau', get_stylesheet_directory_uri() . '/vendors/gauge.js/dist/gauge.min.js' );
	wp_enqueue_script('bootbar', get_stylesheet_directory_uri() . '/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js' );
	wp_enqueue_script('ich', get_stylesheet_directory_uri() . '/vendors/iCheck/icheck.min.js' );
	wp_enqueue_script('sky', get_stylesheet_directory_uri() . '/vendors/skycons/skycons.js' );
	wp_enqueue_script('flo', get_stylesheet_directory_uri() . '/vendors/Flot/jquery.flot.js' );
	wp_enqueue_script('pi', get_stylesheet_directory_uri() . '/vendors/Flot/jquery.flot.pie.js' );
	wp_enqueue_script('tim', get_stylesheet_directory_uri() . '/vendors/Flot/jquery.flot.time.js' );
	wp_enqueue_script('stac', get_stylesheet_directory_uri() . '/vendors/Flot/jquery.flot.stack.js' );
	wp_enqueue_script('resi', get_stylesheet_directory_uri() . '/vendors/Flot/jquery.flot.resize.js' );
	wp_enqueue_script('ord', get_stylesheet_directory_uri() . '/vendors/flot.orderbars/js/jquery.flot.orderBars.js' );
	wp_enqueue_script('spl', get_stylesheet_directory_uri() . '/vendors/flot-spline/js/jquery.flot.spline.min.js' );
	wp_enqueue_script('curve', get_stylesheet_directory_uri() . '/vendors/flot.curvedlines/curvedLines.js' );
	wp_enqueue_script('date', get_stylesheet_directory_uri() . '/vendors/DateJS/build/date.js' );
	wp_enqueue_script('vmap', get_stylesheet_directory_uri() . '/vendors/jqvmap/dist/jquery.vmap.js' );
	wp_enqueue_script('world', get_stylesheet_directory_uri() . '/vendors/jqvmap/dist/maps/jquery.vmap.world.js' );
	wp_enqueue_script('sample', get_stylesheet_directory_uri() . '/vendors/jqvmap/examples/js/jquery.vmap.sampledata.js' );
	wp_enqueue_script('mom', get_stylesheet_directory_uri() . '/vendors/moment/min/moment.min.js' );
	wp_enqueue_script('bootdate', get_stylesheet_directory_uri() . '/vendors/bootstrap-daterangepicker/daterangepicker.js' );
	wp_enqueue_script('custom', get_stylesheet_directory_uri() . '/build/css/custom.min.css' );
}


add_action('wp_enqueue_scripts', 'my_theme_enqueue_styles');
